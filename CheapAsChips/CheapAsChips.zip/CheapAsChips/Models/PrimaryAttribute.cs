﻿using System;

namespace CheapAsChips.Models
{
    internal class PrimaryAttribute : Attribute
    {
    }
}